import  TaskUI from './TaskUI'
// import  ViewTaskUI from './components/ViewTaskUI';

function App() {
  return (
    <div className="App">
      <TaskUI />
      
     </div>
  );
}

export default App;