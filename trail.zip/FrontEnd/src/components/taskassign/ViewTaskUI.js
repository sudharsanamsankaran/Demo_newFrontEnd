import React,{Component} from 'react';
import './taskUI.css';
import axios from 'axios';
import queryString from 'query-string';
import { useParams } from "react-router";
import { string } from 'prop-types';
import { Link } from 'react-router-dom';
//import ReactDOM from 'react-dom';

var tid1 = new URL(window.location.href).pathname.slice(12);
console.log(tid1);

class ViewTaskUI extends Component{
    
    constructor(props){
       
        super(props);
        this.state={
            status:"",
            details:[],
        }
   

       this.componentDidMount= this.componentDidMount.bind(this);
       this.statusChange= this.statusChange.bind(this);
    }
    statusChange(event){
        this.setState({status:event.target.value });
        var stat=event.target.value;
        var data1={
            status:stat
        }
        console.log(stat)
        axios.patch(`http://localhost:3001/taskcreation/${tid1}`);
    }
   
    componentDidMount(){
            // axios({
            //     method: 'GET',
            //     url: `http://localhost:3001/taskcreation/`,
            //     headers: {
            //         'Content-Type': 'application/json',
            //         'Accept': 'application/json'
            //     },
            //     params: {
            //         taskid :"T47485477"
            //     }
            //     })
                // axios.get('https://httpbin.org/get', { params: {taskid :"T47485477"} })
                axios.get(`http://localhost:3001/taskcreation/${tid1}`)
                .then(response=>{
                    console.log(response);
                    this.setState({details:response.data})
            } )
   } 
   componentDidUnmount(){

    tid1=null;
   } 
    render(){
        const {details} = this.state;
        // var tid=this.state.match.params;
        // // console.log(tid);
        // let url =this.props.location.search;  
        // let params = queryString.parse(url);  
        // console.log(params);
        
        return(
            <div className="div8">
                <Link to='/associate/*'>

<button className='back-btn'>Back</button>

</Link>
                <div className="div4">Task ID</div>
                <div className="div5">{details.taskid}</div>
                <div className="div4">Task Name</div>
                <div className="div5">{details.taskname}</div>
                <div className="div4">Task Description</div>
                <div className="div6">{details.taskdescription}</div>
                <div className="div7">
                    <button className="submit1">View Documnets</button>
                    <select className="sel" name="status"  onChange={this.statusChange}>
                        <option hidden disabled selected value>select status </option>
                        <option value="New" >New</option>
                        <option value="In Progress" >In Progress</option>
                        <option value="Completed" >Completed</option>
                    </select>

                    
                </div>
            </div>
            )
    }
}
    export default  ViewTaskUI;