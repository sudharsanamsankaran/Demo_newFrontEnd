import React, { useEffect } from "react";
import Chart from "chart.js/auto";
import axios from "axios";
import { uid } from "../../login/login";
import '../dashboard.css'

function DoughnutAssociateChart() {
    const [count, setCount] = React.useState([]);
    useEffect(() => {
        let requesteddata = false;
        axios.get(`http://localhost:3001/associatetasks/totalcount/${uid}`)
            .then(res => {
                console.log(res);
                if (!requesteddata) {
                    setCount(res.data.tcount)
                }
                console.log(count);





                const ctx = document.getElementById("doughnutchartassociate");

                let chartStatus = Chart.getChart("doughnutchartassociate");
                if (chartStatus != undefined) {
                    chartStatus.destroy();
                }
                new Chart(ctx, {
                    type: "doughnut",
                    data: {
                        labels: ["New", "Inprogress", "Compeleted", "Total"],
                        datasets: [
                            {
                                label: "chart",
                                data: [2, 5, 2, res.data.tcount],
                                backgroundColor: [
                                    "#5dadec",
                                    "#2a52be",
                                    "#21abcd",
                                    "#89cff0"
                                ],
                                borderColor: [" DarkGreen"],
                                borderWidth: 1
                            }
                        ]
                    }

                })
                    ;
            })
    });
    return (
        <div className="chart">
            <canvas id="doughnutchartassociate" width="400" height="400" />
        </div>
    );
}

export default DoughnutAssociateChart;


