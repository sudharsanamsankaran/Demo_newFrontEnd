import React, { useEffect } from "react";
import Chart from "chart.js/auto";
import axios from "axios";
import { uid } from "../../login/login";
import '../dashboard.css'

function DoughnutChartlead() {
    const [count, setCount] = React.useState([]);
    useEffect(() => {
        let requesteddata = false;
        axios.get(`http://localhost:3001/leadertasks/totalcount/${uid}`)
            .then(res => {
                console.log(res);
                if (!requesteddata) {
                    setCount(res.data.tcount)
                }
                console.log(count);





                const ctx = document.getElementById("doughnutchartlead");
                let chartStatus = Chart.getChart("doughnutchartlead");
                if (chartStatus != undefined) {
                    chartStatus.destroy();
                }
                new Chart(ctx, {
                    type: "doughnut",
                    data: {
                        labels: ["New", "Inprogress", "Compeleted", "Total"],
                        datasets: [
                            {
                                label: "chart",
                                data: [2, 3, 2, res.data.tcount],
                                backgroundColor: [
                                    "Aqua",
                                    "#ff66cc",
                                    "#7A5299",
                                    "SkyBlue"
                                ],                             
                                borderColor: ["DarkGreen"],
                                borderWidth: 3
                            }
                        ]
                    },
                        options: {
                          responsive: true,
                          plugins: {
                            legend: {
                              position: 'right',
                            },
                            title: {
                              display: true,
                              text: 'Task Management'
                            }
                          }
                        },

                })
                    ;
            })
    });
    return (
        <div className="chart">
            <canvas id="doughnutchartlead" width="400" height="400" />
        </div>
    );
}

export default DoughnutChartlead;


