import React from 'react';
import "antd/dist/antd.css";
import { Button, Input, Table } from "antd";
import { useState } from "react";
import { SearchOutlined } from "@ant-design/icons";
import axios from 'axios';
import { uid } from "../login/login";
import './dashboard.css';


function Dashboardsearch() {
  const [dataSource, setDataSource] = useState([{ taskid: "", taskdescription: "", associate: "" }])

  React.useEffect(() => {
    axios.get(`http://localhost:3001/leadertasks/userdetails/${uid}`).then((response) => {
      setDataSource(response.data);
      console.log(response.data)
    })
      .catch(error => console.log(error))
  }, []);


  const columns = [
    {
      title: "Task_id",
      dataIndex: "taskid",
      filterDropdown: ({
        setSelectedKeys,
        selectedKeys,
        confirm,
        clearFilters,
      }) => {
        return (
          <>
            <Input
              autoFocus
              placeholder="Type text here"
              value={selectedKeys[0]}
              onChange={(e) => {
                setSelectedKeys(e.target.value ? [e.target.value] : []);
                confirm({ closeDropdown: false });
              }}
              onPressEnter={() => {
                confirm();
              }}
              onBlur={() => {
                confirm();
              }}
            ></Input>
            <Button
              onClick={() => {
                confirm();
              }}
              type="primary"
            >
              Search
            </Button>
            <Button
              onClick={() => {
                clearFilters();
              }}
              type="danger"
            >
              Reset
            </Button>
          </>
        );
      },
      filterIcon: () => {
        return <SearchOutlined />;
      },
      onFilter: (value, record) => {
        return record.taskid.toLowerCase().includes(value.toLowerCase());
      },
    },
    {
      title: " Task_Description",
      dataIndex: "taskdescription",
      filterDropdown: ({
        setSelectedKeys,
        selectedKeys,
        confirm,
        clearFilters,
      }) => {
        return (
          <>
            <Input
              autoFocus
              placeholder="Type text here"
              value={selectedKeys[0]}
              onChange={(e) => {
                setSelectedKeys(e.target.value ? [e.target.value] : []);
                confirm({ closeDropdown: false });
              }}
              onPressEnter={() => {
                confirm();
              }}
              onBlur={() => {
                confirm();
              }}
            ></Input>
            <Button
              onClick={() => {
                confirm();
              }}
              type="primary"
            >
              Search
            </Button>
            <Button
              onClick={() => {
                clearFilters();
              }}
              type="danger"
            >
              Reset
            </Button>
          </>
        );
      },
      filterIcon: () => {
        return <SearchOutlined />;
      },
      onFilter: (value, record) => {
        return record.taskdescription.toLowerCase().includes(value.toLowerCase());
      },
    },
    {
      title: " Associate_id",
      dataIndex: "associate",
      filterDropdown: ({
        setSelectedKeys,
        selectedKeys,
        confirm,
        clearFilters,
      }) => {
        return (
          <div style={{ display: "flex", flex: 1, justifyContent: "center" }}>
            <Input
              autoFocus
              placeholder="Type text here"
              value={selectedKeys[0]}
              onChange={(e) => {
                setSelectedKeys(e.target.value ? [e.target.value] : []);
                confirm({ closeDropdown: false });
              }}
              onPressEnter={() => {
                confirm();
              }}
              onBlur={() => {
                confirm();
              }}
            ></Input>
            <Button
              onClick={() => {
                confirm();
              }}
              type="primary"
            >
              Search
            </Button>
            <Button
              onClick={() => {
                clearFilters();
              }}
              type="danger"
            >
              Reset
            </Button>
          </div>
        );
      },
      filterIcon: () => {
        return <SearchOutlined />;
      },
      onFilter: (value, record) => {
        return record.associate.toLowerCase().includes(value.toLowerCase());
      },
    },
  ];
  return (
    <div className="App">
      <header className="App-header">
        <Table
          style={{ display: "flex", flex: 1, margin: 10 }}
          columns={columns}
          dataSource={dataSource}
        ></Table>
      </header>
    </div>
  );
}

export default Dashboardsearch;